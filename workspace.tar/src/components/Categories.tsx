import { categories } from '../data/products';

interface CategoriesProps {
  onCategoryClick: (category: string) => void;
  activeCategory: string;
}

export default function Categories({ onCategoryClick, activeCategory }: CategoriesProps) {
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
            Shop by Category
          </h2>
          <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
            Find the perfect products for your hair care routine from our curated collections
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
          <button
            onClick={() => onCategoryClick('All')}
            className={`group p-6 rounded-2xl border-2 transition-all duration-300 text-center ${
              activeCategory === 'All'
                ? 'border-amber-500 bg-amber-50 shadow-lg shadow-amber-100'
                : 'border-gray-100 hover:border-amber-300 hover:bg-amber-50/50'
            }`}
          >
            <span className="text-4xl block mb-2">🛍️</span>
            <p className="font-semibold text-gray-800 text-sm">All Products</p>
            <p className="text-xs text-gray-500 mt-1">12 items</p>
          </button>

          {categories.map((cat) => (
            <button
              key={cat.name}
              onClick={() => onCategoryClick(cat.name)}
              className={`group p-6 rounded-2xl border-2 transition-all duration-300 text-center ${
                activeCategory === cat.name
                  ? 'border-amber-500 bg-amber-50 shadow-lg shadow-amber-100'
                  : 'border-gray-100 hover:border-amber-300 hover:bg-amber-50/50'
              }`}
            >
              <span className="text-4xl block mb-2">{cat.icon}</span>
              <p className="font-semibold text-gray-800 text-sm">{cat.name}</p>
              <p className="text-xs text-gray-500 mt-1">{cat.count} items</p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
}
