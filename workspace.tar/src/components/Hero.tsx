import { ArrowRight, Star } from 'lucide-react';

export default function Hero() {
  return (
    <section id="home" className="relative min-h-screen flex items-center overflow-hidden bg-gradient-to-br from-amber-50 via-orange-50 to-yellow-50">
      {/* Decorative elements */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 left-10 w-72 h-72 bg-amber-200/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-yellow-200/30 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-orange-100/20 rounded-full blur-3xl"></div>
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-20 lg:pt-0">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="text-center lg:text-left">
            <div className="inline-flex items-center gap-2 bg-amber-100 text-amber-800 px-4 py-1.5 rounded-full text-sm font-medium mb-6">
              <Star size={14} className="fill-amber-500 text-amber-500" />
              <span>#1 Natural Hair Care Brand 2026</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold text-gray-900 leading-tight">
              Unlock Your
              <span className="block bg-gradient-to-r from-amber-600 via-yellow-600 to-orange-600 bg-clip-text text-transparent">
                Hair's Natural
              </span>
              <span className="block">Radiance</span>
            </h1>
            
            <p className="mt-6 text-lg text-gray-600 max-w-lg mx-auto lg:mx-0">
              Discover our collection of premium, cold-pressed hair oils and natural treatments crafted with the finest botanical ingredients for lustrous, healthy hair.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
              <a
                href="#shop"
                className="inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-600 to-yellow-600 text-white px-8 py-4 rounded-full font-semibold text-lg shadow-lg shadow-amber-200 hover:shadow-xl hover:shadow-amber-300 transform hover:-translate-y-0.5 transition-all duration-300"
              >
                Shop Now
                <ArrowRight size={20} />
              </a>
              <a
                href="#about"
                className="inline-flex items-center justify-center gap-2 border-2 border-amber-600 text-amber-700 px-8 py-4 rounded-full font-semibold text-lg hover:bg-amber-50 transition-all duration-300"
              >
                Our Story
              </a>
            </div>

            {/* Stats */}
            <div className="mt-12 grid grid-cols-3 gap-6 max-w-md mx-auto lg:mx-0">
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-amber-700">50K+</p>
                <p className="text-sm text-gray-500">Happy Customers</p>
              </div>
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-amber-700">100%</p>
                <p className="text-sm text-gray-500">Natural Ingredients</p>
              </div>
              <div>
                <p className="text-2xl lg:text-3xl font-bold text-amber-700">4.9</p>
                <p className="text-sm text-gray-500">Average Rating</p>
              </div>
            </div>
          </div>

          {/* Right - Hero Visual */}
          <div className="relative flex justify-center lg:justify-end">
            <div className="relative w-80 h-80 sm:w-96 sm:h-96 lg:w-[450px] lg:h-[450px]">
              {/* Main circle */}
              <div className="absolute inset-0 bg-gradient-to-br from-amber-300 to-yellow-400 rounded-full shadow-2xl shadow-amber-200 flex items-center justify-center">
                <div className="text-center">
                  <span className="text-8xl sm:text-9xl">🫒</span>
                  <p className="text-white font-bold text-lg mt-2">Premium Quality</p>
                </div>
              </div>
              
              {/* Floating elements */}
              <div className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-lg p-3 animate-bounce">
                <span className="text-3xl">🌿</span>
              </div>
              <div className="absolute -bottom-4 -left-4 bg-white rounded-2xl shadow-lg p-3 animate-bounce delay-500">
                <span className="text-3xl">✨</span>
              </div>
              <div className="absolute top-1/2 -left-8 bg-white rounded-2xl shadow-lg p-3 animate-bounce delay-300">
                <span className="text-3xl">💧</span>
              </div>
              <div className="absolute top-10 -right-8 bg-white rounded-2xl shadow-lg p-3 animate-bounce delay-700">
                <span className="text-3xl">🌱</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-amber-400 rounded-full flex justify-center">
          <div className="w-1.5 h-3 bg-amber-400 rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
}
