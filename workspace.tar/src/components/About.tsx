export default function About() {
  return (
    <section id="about" className="py-20 bg-white overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          {/* Left - Visual */}
          <div className="relative">
            <div className="relative bg-gradient-to-br from-amber-100 to-orange-100 rounded-3xl p-12 lg:p-16">
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
                  <span className="text-5xl block mb-2">🌿</span>
                  <p className="text-sm font-semibold text-gray-700">Organic</p>
                </div>
                <div className="bg-white rounded-2xl p-6 shadow-lg text-center mt-8">
                  <span className="text-5xl block mb-2">🧪</span>
                  <p className="text-sm font-semibold text-gray-700">Lab Tested</p>
                </div>
                <div className="bg-white rounded-2xl p-6 shadow-lg text-center">
                  <span className="text-5xl block mb-2">🌍</span>
                  <p className="text-sm font-semibold text-gray-700">Sustainable</p>
                </div>
                <div className="bg-white rounded-2xl p-6 shadow-lg text-center mt-8">
                  <span className="text-5xl block mb-2">❤️</span>
                  <p className="text-sm font-semibold text-gray-700">Cruelty Free</p>
                </div>
              </div>
              
              {/* Decorative */}
              <div className="absolute -top-4 -right-4 w-24 h-24 bg-amber-300/30 rounded-full blur-xl"></div>
              <div className="absolute -bottom-4 -left-4 w-32 h-32 bg-orange-300/30 rounded-full blur-xl"></div>
            </div>
          </div>

          {/* Right - Content */}
          <div>
            <h2 className="text-3xl lg:text-4xl font-bold text-gray-900 mb-6">
              Rooted in Nature,
              <span className="block text-amber-600">Backed by Science</span>
            </h2>
            
            <p className="text-gray-600 leading-relaxed mb-6">
              Founded in 2018, Lustré was born from a simple belief: nature holds the key to beautiful, healthy hair. 
              Our founder, a third-generation herbalist, combined ancient botanical wisdom with modern hair science 
              to create formulas that truly work.
            </p>
            
            <p className="text-gray-600 leading-relaxed mb-8">
              Every product in our collection is crafted in small batches using ethically sourced, 
              organic ingredients from sustainable farms around the world. We never compromise on quality 
              because your hair deserves the very best.
            </p>

            <div className="grid grid-cols-2 gap-6">
              <div className="border-l-4 border-amber-500 pl-4">
                <p className="text-2xl font-bold text-gray-900">8+</p>
                <p className="text-sm text-gray-500">Years of Excellence</p>
              </div>
              <div className="border-l-4 border-amber-500 pl-4">
                <p className="text-2xl font-bold text-gray-900">30+</p>
                <p className="text-sm text-gray-500">Countries Served</p>
              </div>
              <div className="border-l-4 border-amber-500 pl-4">
                <p className="text-2xl font-bold text-gray-900">50K+</p>
                <p className="text-sm text-gray-500">Products Sold</p>
              </div>
              <div className="border-l-4 border-amber-500 pl-4">
                <p className="text-2xl font-bold text-gray-900">4.9★</p>
                <p className="text-sm text-gray-500">Customer Rating</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
