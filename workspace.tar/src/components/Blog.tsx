import { ArrowRight } from 'lucide-react';

const blogPosts = [
  {
    id: 1,
    title: "5 Essential Oils for Hair Growth You Need to Try",
    excerpt: "Discover the science-backed essential oils that can transform your hair growth journey naturally.",
    category: "Hair Growth",
    readTime: "5 min read",
    emoji: "🌿",
    color: "from-emerald-400 to-teal-500"
  },
  {
    id: 2,
    title: "The Complete Guide to Oil Washing Your Hair",
    excerpt: "Learn the ancient technique of oil washing and how it can revolutionize your hair care routine.",
    category: "Hair Care Tips",
    readTime: "7 min read",
    emoji: "💧",
    color: "from-blue-400 to-indigo-500"
  },
  {
    id: 3,
    title: "Why Your Scalp Health Matters More Than You Think",
    excerpt: "A healthy scalp is the foundation of beautiful hair. Here's everything you need to know.",
    category: "Scalp Care",
    readTime: "4 min read",
    emoji: "✨",
    color: "from-amber-400 to-orange-500"
  }
];

export default function Blog() {
  return (
    <section id="blog" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
            Hair Care Tips & Guides
          </h2>
          <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
            Expert advice and natural remedies for your healthiest hair yet
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts.map((post) => (
            <article
              key={post.id}
              className="group bg-white rounded-2xl overflow-hidden border border-gray-100 hover:shadow-xl hover:shadow-amber-50 transition-all duration-300 hover:-translate-y-1"
            >
              <div className={`h-48 bg-gradient-to-br ${post.color} flex items-center justify-center`}>
                <span className="text-7xl group-hover:scale-110 transition-transform duration-300">
                  {post.emoji}
                </span>
              </div>
              <div className="p-6">
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-xs font-bold text-amber-600 bg-amber-50 px-3 py-1 rounded-full">
                    {post.category}
                  </span>
                  <span className="text-xs text-gray-400">{post.readTime}</span>
                </div>
                <h3 className="font-bold text-gray-900 text-lg mb-2 group-hover:text-amber-700 transition-colors">
                  {post.title}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-4">
                  {post.excerpt}
                </p>
                <a
                  href="#"
                  className="inline-flex items-center gap-1 text-amber-600 font-semibold text-sm hover:text-amber-700 transition-colors group/link"
                >
                  Read More
                  <ArrowRight size={14} className="group-hover/link:translate-x-1 transition-transform" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
