import ProductCard from './ProductCard';
import { Product } from '../data/products';

interface ProductsProps {
  products: Product[];
  onAddToCart: (product: Product) => void;
}

export default function Products({ products, onAddToCart }: ProductsProps) {
  return (
    <section id="shop" className="py-16 bg-gradient-to-b from-white to-amber-50/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
            Our Premium Collection
          </h2>
          <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
            Handcrafted with love using the finest natural ingredients sourced from around the world
          </p>
        </div>

        {products.length === 0 ? (
          <div className="text-center py-16">
            <span className="text-6xl block mb-4">🔍</span>
            <p className="text-gray-500 text-lg">No products found in this category</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} onAddToCart={onAddToCart} />
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
