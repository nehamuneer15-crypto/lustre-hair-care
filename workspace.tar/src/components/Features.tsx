import { Leaf, Droplets, Shield, Sparkles, Recycle, Award } from 'lucide-react';

const features = [
  {
    icon: Leaf,
    title: "100% Natural",
    description: "Every ingredient is carefully sourced from nature. No parabens, sulfates, or synthetic chemicals.",
    color: "text-emerald-600",
    bg: "bg-emerald-50"
  },
  {
    icon: Droplets,
    title: "Cold-Pressed",
    description: "Our oils are cold-pressed to preserve maximum nutrients, vitamins, and essential fatty acids.",
    color: "text-blue-600",
    bg: "bg-blue-50"
  },
  {
    icon: Shield,
    title: "Dermatologist Tested",
    description: "All products are clinically tested and approved safe for all hair types and sensitive scalps.",
    color: "text-purple-600",
    bg: "bg-purple-50"
  },
  {
    icon: Sparkles,
    title: "Visible Results",
    description: "See noticeable improvement in hair texture, shine, and strength within just 2-4 weeks of use.",
    color: "text-amber-600",
    bg: "bg-amber-50"
  },
  {
    icon: Recycle,
    title: "Eco-Friendly",
    description: "Sustainable packaging, cruelty-free practices, and carbon-neutral shipping on all orders.",
    color: "text-teal-600",
    bg: "bg-teal-50"
  },
  {
    icon: Award,
    title: "Award Winning",
    description: "Recognized by leading beauty publications and trusted by professional stylists worldwide.",
    color: "text-rose-600",
    bg: "bg-rose-50"
  }
];

export default function Features() {
  return (
    <section id="ingredients" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-gray-900">
            Why Choose Lustré?
          </h2>
          <p className="mt-3 text-gray-600 max-w-2xl mx-auto">
            We believe in the power of nature to transform your hair. Here's what sets us apart.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group p-8 rounded-2xl border border-gray-100 hover:border-amber-200 hover:shadow-lg hover:shadow-amber-50 transition-all duration-300"
            >
              <div className={`w-14 h-14 ${feature.bg} rounded-xl flex items-center justify-center mb-5 group-hover:scale-110 transition-transform duration-300`}>
                <feature.icon className={feature.color} size={28} />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">{feature.title}</h3>
              <p className="text-gray-600 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
