export default function PromoBar() {
  return (
    <div className="bg-gradient-to-r from-amber-700 via-yellow-700 to-amber-700 text-white text-center py-2.5 text-sm font-medium">
      <p>
        🌟 Free Shipping on Orders Over $50 | Use Code <span className="font-bold underline">GLOW15</span> for 15% Off 🌟
      </p>
    </div>
  );
}
