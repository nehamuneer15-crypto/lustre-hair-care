import { Star, ShoppingCart, Heart } from 'lucide-react';
import { Product } from '../data/products';

interface ProductCardProps {
  product: Product;
  onAddToCart: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart }: ProductCardProps) {
  return (
    <div className="group bg-white rounded-2xl border border-gray-100 overflow-hidden hover:shadow-xl hover:shadow-amber-100/50 transition-all duration-300 hover:-translate-y-1">
      {/* Image Area */}
      <div className="relative bg-gradient-to-br from-amber-50 to-orange-50 p-8 flex items-center justify-center h-48">
        <span className="text-7xl group-hover:scale-110 transition-transform duration-300">
          {product.image}
        </span>
        
        {/* Badge */}
        {product.badge && (
          <span className={`absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold text-white ${
            product.badge === 'Bestseller' ? 'bg-gradient-to-r from-amber-500 to-yellow-500' :
            product.badge === 'New' ? 'bg-gradient-to-r from-emerald-500 to-teal-500' :
            product.badge === 'Sale' ? 'bg-gradient-to-r from-red-500 to-pink-500' :
            'bg-gradient-to-r from-purple-500 to-indigo-500'
          }`}>
            {product.badge}
          </span>
        )}

        {/* Wishlist Button */}
        <button className="absolute top-3 right-3 p-2 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-red-50 hover:text-red-500">
          <Heart size={16} />
        </button>
      </div>

      {/* Content */}
      <div className="p-5">
        <p className="text-xs font-medium text-amber-600 uppercase tracking-wider mb-1">{product.category}</p>
        <h3 className="font-bold text-gray-900 text-sm leading-tight mb-2 line-clamp-2 min-h-[2.5rem]">
          {product.name}
        </h3>
        
        {/* Rating */}
        <div className="flex items-center gap-1 mb-3">
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                size={12}
                className={i < Math.floor(product.rating) ? 'text-amber-400 fill-amber-400' : 'text-gray-200'}
              />
            ))}
          </div>
          <span className="text-xs text-gray-500">({product.reviews})</span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2 mb-4">
          <span className="text-xl font-bold text-gray-900">${product.price}</span>
          {product.originalPrice && (
            <span className="text-sm text-gray-400 line-through">${product.originalPrice}</span>
          )}
          {product.originalPrice && (
            <span className="text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
              -{Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}%
            </span>
          )}
        </div>

        {/* Add to Cart */}
        <button
          onClick={() => onAddToCart(product)}
          className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-yellow-500 text-white py-2.5 rounded-xl font-semibold text-sm hover:from-amber-600 hover:to-yellow-600 transition-all duration-300 shadow-md shadow-amber-100 hover:shadow-lg hover:shadow-amber-200"
        >
          <ShoppingCart size={16} />
          Add to Cart
        </button>
      </div>
    </div>
  );
}
