export interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  category: string;
  rating: number;
  reviews: number;
  description: string;
  badge?: string;
  ingredients: string[];
}

export const products: Product[] = [
  {
    id: 1,
    name: "Argan Gold Elixir Hair Oil",
    price: 34.99,
    originalPrice: 44.99,
    image: "🫒",
    category: "Hair Oils",
    rating: 4.9,
    reviews: 234,
    description: "Pure Moroccan argan oil blend for deep nourishment and brilliant shine. Restores damaged hair from root to tip.",
    badge: "Bestseller",
    ingredients: ["Argan Oil", "Vitamin E", "Jojoba Oil", "Rosemary Extract"]
  },
  {
    id: 2,
    name: "Rosemary Growth Serum",
    price: 28.99,
    image: "🌿",
    category: "Serums",
    rating: 4.8,
    reviews: 189,
    description: "Stimulates hair growth with organic rosemary and biotin complex. Visible results in 4-6 weeks.",
    badge: "New",
    ingredients: ["Rosemary Oil", "Biotin", "Castor Oil", "Peppermint Oil"]
  },
  {
    id: 3,
    name: "Keratin Repair Mask",
    price: 32.99,
    image: "✨",
    category: "Masks",
    rating: 4.7,
    reviews: 156,
    description: "Intensive keratin treatment that repairs split ends and strengthens brittle hair in just 10 minutes.",
    ingredients: ["Hydrolyzed Keratin", "Coconut Oil", "Silk Proteins", "Hyaluronic Acid"]
  },
  {
    id: 4,
    name: "Coconut & Hibiscus Deep Conditioner",
    price: 26.99,
    originalPrice: 32.99,
    image: "🥥",
    category: "Conditioners",
    rating: 4.6,
    reviews: 201,
    description: "Rich, creamy deep conditioner with tropical coconut and hibiscus for silky smooth hair.",
    badge: "Sale",
    ingredients: ["Coconut Oil", "Hibiscus Extract", "Shea Butter", "Aloe Vera"]
  },
  {
    id: 5,
    name: "Tea Tree Scalp Treatment Oil",
    price: 29.99,
    image: "🍃",
    category: "Hair Oils",
    rating: 4.8,
    reviews: 178,
    description: "Soothes itchy scalp and eliminates dandruff with powerful tea tree and eucalyptus blend.",
    ingredients: ["Tea Tree Oil", "Eucalyptus", "Neem Oil", "Aloe Vera"]
  },
  {
    id: 6,
    name: "Biotin Strengthening Shampoo",
    price: 22.99,
    image: "🧴",
    category: "Shampoos",
    rating: 4.5,
    reviews: 312,
    description: "Sulfate-free formula enriched with biotin to strengthen hair and prevent breakage.",
    ingredients: ["Biotin", "Saw Palmetto", "Green Tea", "Panthenol"]
  },
  {
    id: 7,
    name: "Amla & Bhringraj Hair Oil",
    price: 31.99,
    image: "🌱",
    category: "Hair Oils",
    rating: 4.9,
    reviews: 267,
    description: "Ancient Ayurvedic formula for hair growth and prevention of premature greying. 100% natural.",
    badge: "Bestseller",
    ingredients: ["Amla", "Bhringraj", "Sesame Oil", "Brahmi"]
  },
  {
    id: 8,
    name: "Heat Protectant Spray",
    price: 19.99,
    image: "💨",
    category: "Styling",
    rating: 4.4,
    reviews: 145,
    description: "Lightweight spray that protects hair from heat damage up to 450°F while adding shine.",
    ingredients: ["Argan Oil", "Silk Proteins", "Vitamin B5", "UV Filters"]
  },
  {
    id: 9,
    name: "Castor Oil Hair Growth Pack",
    price: 27.99,
    originalPrice: 35.99,
    image: "💧",
    category: "Hair Oils",
    rating: 4.7,
    reviews: 198,
    description: "Cold-pressed Jamaican black castor oil for thicker, fuller hair. Promotes eyelash and eyebrow growth too.",
    badge: "Sale",
    ingredients: ["Black Castor Oil", "Vitamin E", "Lavender Oil", "Coconut Oil"]
  },
  {
    id: 10,
    name: "Silk & Shine Leave-In Conditioner",
    price: 24.99,
    image: "🦋",
    category: "Conditioners",
    rating: 4.6,
    reviews: 167,
    description: "Weightless leave-in formula that detangles, moisturizes, and adds silk-like shine all day.",
    ingredients: ["Silk Amino Acids", "Argan Oil", "Glycerin", "Panthenol"]
  },
  {
    id: 11,
    name: "Anti-Frizz Smoothing Serum",
    price: 25.99,
    image: "💎",
    category: "Serums",
    rating: 4.5,
    reviews: 223,
    description: "Tames frizz and flyaways instantly with a lightweight, non-greasy silicone-free formula.",
    ingredients: ["Broccoli Seed Oil", "Camellia Oil", "Vitamin E", "Bamboo Extract"]
  },
  {
    id: 12,
    name: "Scalp Detox Clay Mask",
    price: 29.99,
    image: "🏔️",
    category: "Masks",
    rating: 4.7,
    reviews: 134,
    description: "Bentonite and kaolin clay mask that draws out impurities and excess oil from the scalp.",
    badge: "New",
    ingredients: ["Bentonite Clay", "Kaolin", "Apple Cider Vinegar", "Tea Tree"]
  }
];

export const categories = [
  { name: "Hair Oils", icon: "🫒", count: 4, color: "from-amber-500 to-yellow-600" },
  { name: "Serums", icon: "💧", count: 2, color: "from-purple-500 to-indigo-600" },
  { name: "Shampoos", icon: "🧴", count: 1, color: "from-blue-500 to-cyan-600" },
  { name: "Conditioners", icon: "🥥", count: 2, color: "from-pink-500 to-rose-600" },
  { name: "Masks", icon: "✨", count: 2, color: "from-emerald-500 to-teal-600" },
  { name: "Styling", icon: "💨", count: 1, color: "from-orange-500 to-red-600" },
];

export const testimonials = [
  {
    id: 1,
    name: "Sarah Mitchell",
    avatar: "👩‍🦰",
    rating: 5,
    text: "The Argan Gold Elixir completely transformed my damaged hair. After just 2 weeks, my hair feels softer and looks healthier than ever!",
    product: "Argan Gold Elixir Hair Oil"
  },
  {
    id: 2,
    name: "Priya Sharma",
    avatar: "👩",
    rating: 5,
    text: "I've tried dozens of hair oils but the Amla & Bhringraj oil is truly special. My hair growth has been incredible and the grey hairs have reduced!",
    product: "Amla & Bhringraj Hair Oil"
  },
  {
    id: 3,
    name: "Jessica Chen",
    avatar: "👩‍🦱",
    rating: 5,
    text: "The Rosemary Growth Serum is a game changer. I can see baby hairs growing along my hairline after just one month of use.",
    product: "Rosemary Growth Serum"
  },
  {
    id: 4,
    name: "Amanda Torres",
    avatar: "👩‍🦳",
    rating: 4,
    text: "Finally found a shampoo that doesn't strip my hair. The Biotin Strengthening Shampoo leaves my hair feeling strong and full of volume.",
    product: "Biotin Strengthening Shampoo"
  }
];
